
#include "variables_funciones.hpp"
#include "SystemBuddy.cpp"
using namespace std;

int main(){
    cout<<"Escoja cualquiera de los espacios siguientes: ";
    cout<<endl<<"1.   1MB"<<endl;
    cout<<"2.   4MB"<<endl;
    cout<<"3.   8MB"<<endl;
    cout<<"Respuesta: ";
    int tam;
    cin>>tam;
    switch(tam){
        case
    }
}